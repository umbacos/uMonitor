# Example configurations

In uMonitor, choose **Open**, select an example, then choose **Open design**. In the portable package, the file browser starts in this `config` directory. Use **Export > Save JSON as…** to save your own copy.

| File | What it demonstrates |
| --- | --- |
| `landscape.json` | A 480 × 320 hardware dashboard with CPU/GPU/RAM gauges, disk/network readings, clock and weather field. Hardware headings are editable sample text. |
| `portrait.json` | A 320 × 480 clock, CPU/RAM gauges and network rates using local readings. |
| `ticker.json` | A circular scrolling ticker combining CPU, RAM and network values with individual decimal settings. |
| `connected-sources.json` | A local JSON endpoint, Home Assistant, Rome weather and an MSFT stock source, ready to configure under Data sources. The widgets initially use local fields. |

The first three examples need no API keys. Unavailable sensors show `N/A`. The landscape weather field needs a weather source and a binding selected in Properties.

For the connected example, change `http://127.0.0.1:8080/metrics` to your JSON endpoint, set your Home Assistant address and long-lived access token, choose a weather location, and enter your Alpha Vantage API key for stocks. Sources are polled after loading, so placeholder endpoints can show connection errors until configured. In **Data sources**, choose **Connect / refresh**; then bind widgets through **Design > Properties > Data binding**. Stock quotes are end-of-day by default, depending on the provider plan.

Examples contain no credentials. Tokens, passwords and API keys are entered in the app and stored in Windows Credential Manager; they do not travel with a copied ZIP or JSON file. Avoid putting secrets in source URLs.
